-- =========================================================
-- Skema Database: Toko Buku Bekas
-- =========================================================

CREATE DATABASE IF NOT EXISTS toko_buku_bekas
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE toko_buku_bekas;

-- ---------------------------------------------------------
-- Tabel: books  (Rumpun CRUD #1)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS books (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  title         VARCHAR(255) NOT NULL,
  author        VARCHAR(255) NOT NULL,
  isbn          VARCHAR(50),
  category      VARCHAR(100) NOT NULL DEFAULT 'Umum',
  `condition`   ENUM('Sangat Baik', 'Baik', 'Cukup') NOT NULL DEFAULT 'Baik',
  price         DECIMAL(10,2) NOT NULL,
  stock         INT NOT NULL DEFAULT 1,
  description   TEXT,
  image_url     VARCHAR(500),
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Tabel: orders  (Rumpun CRUD #2)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS orders (
  id                INT AUTO_INCREMENT PRIMARY KEY,
  customer_name     VARCHAR(255) NOT NULL,
  customer_email    VARCHAR(255) NOT NULL,
  customer_phone    VARCHAR(50),
  customer_address  TEXT NOT NULL,
  status            ENUM('pending','diproses','dikirim','selesai','dibatalkan') NOT NULL DEFAULT 'pending',
  total_amount      DECIMAL(10,2) NOT NULL DEFAULT 0,
  created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Tabel: order_items  (Tabel relasi antara books <-> orders)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS order_items (
  id                  INT AUTO_INCREMENT PRIMARY KEY,
  order_id            INT NOT NULL,
  book_id             INT NOT NULL,
  book_title_snapshot VARCHAR(255) NOT NULL,
  quantity            INT NOT NULL DEFAULT 1,
  price_at_purchase   DECIMAL(10,2) NOT NULL,
  CONSTRAINT fk_order_items_order
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  CONSTRAINT fk_order_items_book
    FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE INDEX idx_books_category ON books(category);
CREATE INDEX idx_orders_status ON orders(status);
