USE toko_buku_bekas;

INSERT INTO books (title, author, isbn, category, `condition`, price, stock, description, image_url) VALUES
('Laskar Pelangi', 'Andrea Hirata', '9789793062792', 'Fiksi', 'Baik', 45000, 3, 'Novel legendaris tentang perjuangan anak-anak Belitung mengejar pendidikan.', 'https://covers.openlibrary.org/b/id/8231856-L.jpg'),
('Bumi Manusia', 'Pramoedya Ananta Toer', '9789799731234', 'Fiksi', 'Sangat Baik', 60000, 2, 'Novel sejarah karya sastrawan besar Indonesia, bagian dari Tetralogi Buru.', 'https://covers.openlibrary.org/b/id/9251996-L.jpg'),
('Filosofi Teras', 'Henry Manampiring', '9786020633176', 'Pengembangan Diri', 'Baik', 55000, 5, 'Pengantar filsafat Stoa yang relevan untuk kehidupan modern.', 'https://covers.openlibrary.org/b/id/10521252-L.jpg'),
('Atomic Habits', 'James Clear', '9780735211292', 'Pengembangan Diri', 'Sangat Baik', 70000, 4, 'Panduan praktis membangun kebiasaan baik dan menghilangkan kebiasaan buruk.', 'https://covers.openlibrary.org/b/id/8534562-L.jpg'),
('Sapiens', 'Yuval Noah Harari', '9789602911476', 'Non-Fiksi', 'Cukup', 65000, 2, 'Sejarah singkat umat manusia dari zaman batu hingga era modern.', 'https://covers.openlibrary.org/b/id/8375138-L.jpg'),
('Pulang', 'Tere Liye', '9786020341507', 'Fiksi', 'Baik', 40000, 6, 'Kisah aksi dan drama keluarga dari penulis best seller Tere Liye.', 'https://covers.openlibrary.org/b/id/8406786-L.jpg'),
('Negeri 5 Menara', 'Ahmad Fuadi', '9789792248160', 'Fiksi', 'Cukup', 35000, 3, 'Kisah inspiratif santri Pondok Madani mengejar mimpi hingga ke penjuru dunia.', 'https://covers.openlibrary.org/b/id/7360823-L.jpg'),
('Cantik Itu Luka', 'Eka Kurniawan', '9789799731357', 'Fiksi', 'Baik', 50000, 2, 'Novel magis realis tentang sejarah dan kekerasan di sebuah kota kecil.', 'https://covers.openlibrary.org/b/id/8406790-L.jpg');
