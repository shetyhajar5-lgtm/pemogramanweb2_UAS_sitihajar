const express = require("express");
const cors = require("cors");
require("dotenv").config();

const booksRoutes = require("./src/routes/books.routes");
const ordersRoutes = require("./src/routes/orders.routes");

const app = express();

app.use(cors());
app.use(express.json());

app.get("/api/health", (req, res) => {
  res.json({ success: true, message: "API Toko Buku Bekas berjalan dengan baik" });
});

app.use("/api/books", booksRoutes);
app.use("/api/orders", ordersRoutes);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ success: false, message: "Endpoint tidak ditemukan" });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server berjalan di http://localhost:${PORT}`);
});
