const pool = require("../config/db");

// GET /api/orders?status=
exports.getAllOrders = async (req, res) => {
  try {
    const { status } = req.query;
    let query = "SELECT * FROM orders WHERE 1=1";
    const params = [];
    if (status && status !== "Semua") {
      query += " AND status = ?";
      params.push(status);
    }
    query += " ORDER BY created_at DESC";

    const [orders] = await pool.query(query, params);
    res.json({ success: true, data: orders });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// GET /api/orders/:id  (beserta item-item buku di dalamnya)
exports.getOrderById = async (req, res) => {
  try {
    const { id } = req.params;
    const [orders] = await pool.query("SELECT * FROM orders WHERE id = ?", [id]);
    if (orders.length === 0) {
      return res.status(404).json({ success: false, message: "Transaksi tidak ditemukan" });
    }

    const [items] = await pool.query(
      `SELECT oi.*, b.image_url, b.author
       FROM order_items oi
       LEFT JOIN books b ON b.id = oi.book_id
       WHERE oi.order_id = ?`,
      [id]
    );

    res.json({ success: true, data: { ...orders[0], items } });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// POST /api/orders
// body: { customer_name, customer_email, customer_phone, customer_address, items: [{book_id, quantity}] }
exports.createOrder = async (req, res) => {
  const connection = await pool.getConnection();
  try {
    const { customer_name, customer_email, customer_phone, customer_address, items } = req.body;

    if (!customer_name || !customer_email || !customer_address || !Array.isArray(items) || items.length === 0) {
      connection.release();
      return res.status(400).json({ success: false, message: "Data pemesan dan minimal 1 buku wajib diisi" });
    }

    await connection.beginTransaction();

    let total = 0;
    const itemRows = [];

    for (const item of items) {
      const [bookRows] = await connection.query("SELECT * FROM books WHERE id = ? FOR UPDATE", [item.book_id]);
      if (bookRows.length === 0) {
        throw new Error(`Buku dengan id ${item.book_id} tidak ditemukan`);
      }
      const book = bookRows[0];
      const qty = Number(item.quantity) || 1;

      if (book.stock < qty) {
        throw new Error(`Stok buku "${book.title}" tidak mencukupi (sisa ${book.stock})`);
      }

      total += Number(book.price) * qty;
      itemRows.push({ book_id: book.id, title: book.title, price: book.price, qty });

      await connection.query("UPDATE books SET stock = stock - ? WHERE id = ?", [qty, book.id]);
    }

    const [orderResult] = await connection.query(
      `INSERT INTO orders (customer_name, customer_email, customer_phone, customer_address, status, total_amount)
       VALUES (?, ?, ?, ?, 'pending', ?)`,
      [customer_name, customer_email, customer_phone || null, customer_address, total]
    );
    const orderId = orderResult.insertId;

    for (const it of itemRows) {
      await connection.query(
        `INSERT INTO order_items (order_id, book_id, book_title_snapshot, quantity, price_at_purchase)
         VALUES (?, ?, ?, ?, ?)`,
        [orderId, it.book_id, it.title, it.qty, it.price]
      );
    }

    await connection.commit();

    const [orderRows] = await pool.query("SELECT * FROM orders WHERE id = ?", [orderId]);
    res.status(201).json({ success: true, data: orderRows[0] });
  } catch (err) {
    await connection.rollback();
    res.status(400).json({ success: false, message: err.message });
  } finally {
    connection.release();
  }
};

// PUT /api/orders/:id  (update status transaksi)
exports.updateOrder = async (req, res) => {
  try {
    const { id } = req.params;
    const { status, customer_name, customer_phone, customer_address } = req.body;

    const [existing] = await pool.query("SELECT * FROM orders WHERE id = ?", [id]);
    if (existing.length === 0) {
      return res.status(404).json({ success: false, message: "Transaksi tidak ditemukan" });
    }

    const validStatus = ["pending", "diproses", "dikirim", "selesai", "dibatalkan"];
    if (status && !validStatus.includes(status)) {
      return res.status(400).json({ success: false, message: "Status tidak valid" });
    }

    await pool.query(
      `UPDATE orders SET status=?, customer_name=?, customer_phone=?, customer_address=? WHERE id=?`,
      [
        status ?? existing[0].status,
        customer_name ?? existing[0].customer_name,
        customer_phone ?? existing[0].customer_phone,
        customer_address ?? existing[0].customer_address,
        id,
      ]
    );

    const [rows] = await pool.query("SELECT * FROM orders WHERE id = ?", [id]);
    res.json({ success: true, data: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// DELETE /api/orders/:id  (mengembalikan stok buku sebelum menghapus)
exports.deleteOrder = async (req, res) => {
  const connection = await pool.getConnection();
  try {
    const { id } = req.params;
    await connection.beginTransaction();

    const [items] = await connection.query("SELECT * FROM order_items WHERE order_id = ?", [id]);
    for (const item of items) {
      await connection.query("UPDATE books SET stock = stock + ? WHERE id = ?", [item.quantity, item.book_id]);
    }

    const [result] = await connection.query("DELETE FROM orders WHERE id = ?", [id]);
    if (result.affectedRows === 0) {
      await connection.rollback();
      return res.status(404).json({ success: false, message: "Transaksi tidak ditemukan" });
    }

    await connection.commit();
    res.json({ success: true, message: "Transaksi berhasil dihapus dan stok buku dikembalikan" });
  } catch (err) {
    await connection.rollback();
    res.status(500).json({ success: false, message: err.message });
  } finally {
    connection.release();
  }
};
