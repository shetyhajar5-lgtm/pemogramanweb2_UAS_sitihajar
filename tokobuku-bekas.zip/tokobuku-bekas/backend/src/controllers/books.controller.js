const pool = require("../config/db");

// GET /api/books?search=&category=
exports.getAllBooks = async (req, res) => {
  try {
    const { search, category } = req.query;
    let query = "SELECT * FROM books WHERE 1=1";
    const params = [];

    if (search) {
      query += " AND (title LIKE ? OR author LIKE ?)";
      params.push(`%${search}%`, `%${search}%`);
    }
    if (category && category !== "Semua") {
      query += " AND category = ?";
      params.push(category);
    }
    query += " ORDER BY created_at DESC";

    const [rows] = await pool.query(query, params);
    res.json({ success: true, data: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// GET /api/books/:id
exports.getBookById = async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM books WHERE id = ?", [req.params.id]);
    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: "Buku tidak ditemukan" });
    }
    res.json({ success: true, data: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// POST /api/books
exports.createBook = async (req, res) => {
  try {
    const { title, author, isbn, category, condition, price, stock, description, image_url } = req.body;

    if (!title || !author || !price) {
      return res.status(400).json({ success: false, message: "Judul, penulis, dan harga wajib diisi" });
    }

    const [result] = await pool.query(
      `INSERT INTO books (title, author, isbn, category, \`condition\`, price, stock, description, image_url)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [title, author, isbn || null, category || "Umum", condition || "Baik", price, stock || 1, description || null, image_url || null]
    );

    const [rows] = await pool.query("SELECT * FROM books WHERE id = ?", [result.insertId]);
    res.status(201).json({ success: true, data: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// PUT /api/books/:id
exports.updateBook = async (req, res) => {
  try {
    const { title, author, isbn, category, condition, price, stock, description, image_url } = req.body;
    const { id } = req.params;

    const [existing] = await pool.query("SELECT * FROM books WHERE id = ?", [id]);
    if (existing.length === 0) {
      return res.status(404).json({ success: false, message: "Buku tidak ditemukan" });
    }

    await pool.query(
      `UPDATE books SET title=?, author=?, isbn=?, category=?, \`condition\`=?, price=?, stock=?, description=?, image_url=?
       WHERE id=?`,
      [
        title ?? existing[0].title,
        author ?? existing[0].author,
        isbn ?? existing[0].isbn,
        category ?? existing[0].category,
        condition ?? existing[0].condition,
        price ?? existing[0].price,
        stock ?? existing[0].stock,
        description ?? existing[0].description,
        image_url ?? existing[0].image_url,
        id,
      ]
    );

    const [rows] = await pool.query("SELECT * FROM books WHERE id = ?", [id]);
    res.json({ success: true, data: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// DELETE /api/books/:id
exports.deleteBook = async (req, res) => {
  try {
    const [result] = await pool.query("DELETE FROM books WHERE id = ?", [req.params.id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: "Buku tidak ditemukan" });
    }
    res.json({ success: true, message: "Buku berhasil dihapus" });
  } catch (err) {
    if (err.code === "ER_ROW_IS_REFERENCED_2") {
      return res.status(409).json({
        success: false,
        message: "Buku tidak bisa dihapus karena sudah pernah dipesan pada sebuah transaksi",
      });
    }
    res.status(500).json({ success: false, message: err.message });
  }
};
