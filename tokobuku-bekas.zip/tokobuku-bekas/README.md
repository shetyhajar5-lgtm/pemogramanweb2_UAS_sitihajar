# 📚 Loka Aksara — E-Commerce Toko Buku Bekas

Aplikasi web full-stack untuk toko buku bekas: pelanggan bisa menelusuri katalog dan
memesan buku, sementara admin bisa mengelola data buku dan transaksi.

## Fitur

- **Integrasi Database**: MySQL, diakses lewat `mysql2` (connection pool + transaction).
- **2 Rumpun CRUD yang saling berelasi**:
  - **CRUD Buku** (`books`) — tambah/lihat/ubah/hapus data buku bekas (judul, penulis,
    kondisi, harga, stok, dll).
  - **CRUD Transaksi/Pesanan** (`orders` + `order_items`) — checkout membuat pesanan
    baru yang otomatis mengurangi stok buku terkait (relasi lewat `order_items`),
    admin bisa mengubah status pesanan atau menghapusnya (stok dikembalikan otomatis).
- **Frontend menarik**: React + Tailwind CSS bertema "toko buku" (warna kayu/krem),
  responsif, dengan katalog, pencarian, filter kategori, keranjang belanja, checkout,
  dan dashboard admin.

## Struktur Folder

```
tokobuku-bekas/
├── backend/          # REST API — Express.js + MySQL
│   ├── database/     # schema.sql & seed.sql
│   ├── src/
│   │   ├── config/       # koneksi database
│   │   ├── controllers/  # logic CRUD Buku & Transaksi
│   │   └── routes/       # definisi endpoint
│   └── server.js
└── frontend/         # React + Vite + Tailwind
    └── src/
        ├── api/          # pemanggil endpoint backend
        ├── components/   # Navbar, BookCard, Modal, BookForm, dll
        ├── context/       # CartContext (state keranjang)
        └── pages/         # Catalog, BookDetail, Cart, Checkout,
                            # AdminBooks, AdminOrders
```

## Cara Menjalankan

### 1. Siapkan Database

Pastikan MySQL sudah terinstall dan berjalan, lalu jalankan:

```bash
mysql -u root -p < backend/database/schema.sql
mysql -u root -p < backend/database/seed.sql
```

### 2. Jalankan Backend

```bash
cd backend
cp .env.example .env
# sesuaikan DB_USER / DB_PASSWORD di file .env sesuai konfigurasi MySQL kamu
npm install
npm run dev
```

Backend akan berjalan di `http://localhost:5000`. Cek dengan membuka
`http://localhost:5000/api/health`.

### 3. Jalankan Frontend

Buka terminal baru:

```bash
cd frontend
cp .env.example .env
npm install
npm run dev
```

Frontend akan berjalan di `http://localhost:5173`.

## Endpoint API

### Buku (`/api/books`)
| Method | Endpoint | Keterangan |
|--------|----------|------------|
| GET | `/api/books?search=&category=` | Daftar buku (bisa dicari & difilter) |
| GET | `/api/books/:id` | Detail satu buku |
| POST | `/api/books` | Tambah buku baru |
| PUT | `/api/books/:id` | Ubah data buku |
| DELETE | `/api/books/:id` | Hapus buku |

### Transaksi (`/api/orders`)
| Method | Endpoint | Keterangan |
|--------|----------|------------|
| GET | `/api/orders?status=` | Daftar transaksi |
| GET | `/api/orders/:id` | Detail transaksi + item buku |
| POST | `/api/orders` | Buat transaksi baru (checkout), otomatis mengurangi stok buku |
| PUT | `/api/orders/:id` | Ubah status/data transaksi |
| DELETE | `/api/orders/:id` | Hapus transaksi, stok buku dikembalikan |

## Relasi Data

```
books (1) ───< order_items >─── (1) orders
```

Setiap transaksi (`orders`) memiliki banyak item (`order_items`), dan setiap item
merujuk ke satu buku (`books`). Saat checkout, stok buku otomatis berkurang; saat
transaksi dihapus, stok dikembalikan — inilah relasi nyata antar dua rumpun CRUD.

## Halaman

- `/` — Katalog buku (publik)
- `/books/:id` — Detail buku
- `/cart` — Keranjang belanja
- `/checkout` — Form checkout
- `/order-success/:id` — Konfirmasi pesanan
- `/admin/books` — Dashboard CRUD Buku
- `/admin/orders` — Dashboard CRUD Transaksi
