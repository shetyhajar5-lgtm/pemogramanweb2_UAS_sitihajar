import React, { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { getBook } from "../api/books";
import { useCart } from "../context/CartContext";

export default function BookDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const [book, setBook] = useState(null);
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getBook(id)
      .then(setBook)
      .catch(() => setBook(null))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return <div className="max-w-6xl mx-auto px-4 py-16 text-center text-ink/50">Memuat...</div>;
  if (!book) return <div className="max-w-6xl mx-auto px-4 py-16 text-center text-ink/50">Buku tidak ditemukan.</div>;

  return (
    <div className="max-w-5xl mx-auto px-4 py-10">
      <Link to="/" className="text-sm text-wood hover:underline">&larr; Kembali ke katalog</Link>

      <div className="grid md:grid-cols-2 gap-10 mt-6">
        <div className="aspect-[3/4] bg-parchment rounded-2xl overflow-hidden shadow-sm">
          {book.image_url ? (
            <img src={book.image_url} alt={book.title} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-6xl">📖</div>
          )}
        </div>

        <div>
          <span className="inline-block text-xs px-3 py-1 rounded-full bg-parchment text-wood font-medium mb-3">
            {book.category}
          </span>
          <h1 className="font-display text-3xl font-bold text-woodDark mb-1">{book.title}</h1>
          <p className="text-ink/60 mb-4">oleh {book.author}</p>
          <p className="text-2xl font-bold text-wood mb-4">Rp {Number(book.price).toLocaleString("id-ID")}</p>

          <div className="flex items-center gap-4 mb-4 text-sm">
            <span className="px-3 py-1 rounded-full bg-amber-100 text-amber-700 font-medium">Kondisi: {book.condition}</span>
            <span className={`font-medium ${book.stock > 0 ? "text-leaf" : "text-rust"}`}>
              {book.stock > 0 ? `Stok tersedia: ${book.stock}` : "Stok habis"}
            </span>
          </div>

          <p className="text-ink/80 leading-relaxed mb-6">{book.description || "Tidak ada deskripsi untuk buku ini."}</p>

          {book.stock > 0 && (
            <div className="flex items-center gap-3 mb-4">
              <label className="text-sm text-ink/70">Jumlah:</label>
              <input
                type="number"
                min={1}
                max={book.stock}
                value={qty}
                onChange={(e) => setQty(Math.max(1, Math.min(book.stock, Number(e.target.value))))}
                className="w-20 border border-parchment rounded-lg px-3 py-1.5 bg-white"
              />
            </div>
          )}

          <div className="flex gap-3">
            <button
              disabled={book.stock === 0}
              onClick={() => {
                addToCart(book, qty);
                setAdded(true);
                setTimeout(() => setAdded(false), 1500);
              }}
              className="px-6 py-3 rounded-full bg-wood text-cream font-semibold hover:bg-woodDark disabled:opacity-40 disabled:cursor-not-allowed transition"
            >
              {added ? "✓ Ditambahkan!" : "Tambah ke Keranjang"}
            </button>
            <button
              disabled={book.stock === 0}
              onClick={() => {
                addToCart(book, qty);
                navigate("/cart");
              }}
              className="px-6 py-3 rounded-full border border-wood text-wood font-semibold hover:bg-parchment disabled:opacity-40 disabled:cursor-not-allowed transition"
            >
              Beli Sekarang
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
