import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { useCart } from "../context/CartContext";

export default function Cart() {
  const { items, updateQuantity, removeFromCart, total } = useCart();
  const navigate = useNavigate();

  if (items.length === 0) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center">
        <p className="text-6xl mb-4">🛒</p>
        <h2 className="font-display text-2xl font-bold text-woodDark mb-2">Keranjang masih kosong</h2>
        <p className="text-ink/60 mb-6">Yuk, jelajahi katalog dan temukan buku favoritmu.</p>
        <Link to="/" className="px-6 py-3 rounded-full bg-wood text-cream font-semibold hover:bg-woodDark transition">
          Mulai Belanja
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-10">
      <h1 className="font-display text-2xl font-bold text-woodDark mb-6">Keranjang Belanja</h1>

      <div className="flex flex-col gap-4 mb-8">
        {items.map((item) => (
          <div key={item.book_id} className="flex gap-4 bg-white border border-parchment rounded-2xl p-4 items-center">
            <div className="w-16 h-20 bg-parchment rounded-lg overflow-hidden shrink-0">
              {item.image_url ? (
                <img src={item.image_url} alt={item.title} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center">📖</div>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-ink truncate">{item.title}</p>
              <p className="text-sm text-ink/60">{item.author}</p>
              <p className="text-wood font-bold mt-1">Rp {Number(item.price).toLocaleString("id-ID")}</p>
            </div>
            <input
              type="number"
              min={1}
              max={item.stock}
              value={item.quantity}
              onChange={(e) => updateQuantity(item.book_id, Number(e.target.value))}
              className="w-16 border border-parchment rounded-lg px-2 py-1.5 text-center"
            />
            <button onClick={() => removeFromCart(item.book_id)} className="text-rust hover:text-rust/70 text-sm font-medium">
              Hapus
            </button>
          </div>
        ))}
      </div>

      <div className="bg-parchment rounded-2xl p-6 flex items-center justify-between">
        <span className="font-display font-bold text-lg text-woodDark">Total</span>
        <span className="font-display font-bold text-xl text-wood">Rp {total.toLocaleString("id-ID")}</span>
      </div>

      <button
        onClick={() => navigate("/checkout")}
        className="mt-6 w-full py-3 rounded-full bg-wood text-cream font-semibold hover:bg-woodDark transition"
      >
        Lanjut ke Checkout
      </button>
    </div>
  );
}
