import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { getOrder } from "../api/orders";

export default function OrderSuccess() {
  const { id } = useParams();
  const [order, setOrder] = useState(null);

  useEffect(() => {
    getOrder(id).then(setOrder).catch(() => setOrder(null));
  }, [id]);

  return (
    <div className="max-w-2xl mx-auto px-4 py-20 text-center">
      <p className="text-6xl mb-4">🎉</p>
      <h1 className="font-display text-2xl font-bold text-woodDark mb-2">Pesanan Berhasil Dibuat!</h1>
      <p className="text-ink/60 mb-6">
        Nomor pesanan kamu <span className="font-bold text-wood">#{id}</span>. Kami akan memproses pesananmu segera.
      </p>
      {order && (
        <div className="bg-white border border-parchment rounded-2xl p-6 text-left mb-6">
          <p className="text-sm text-ink/60 mb-1">Total Pembayaran</p>
          <p className="text-xl font-bold text-wood mb-4">Rp {Number(order.total_amount).toLocaleString("id-ID")}</p>
          <p className="text-sm text-ink/60 mb-1">Status</p>
          <span className="inline-block px-3 py-1 rounded-full bg-amber-100 text-amber-700 text-sm font-medium capitalize">
            {order.status}
          </span>
        </div>
      )}
      <Link to="/" className="px-6 py-3 rounded-full bg-wood text-cream font-semibold hover:bg-woodDark transition">
        Kembali Belanja
      </Link>
    </div>
  );
}
