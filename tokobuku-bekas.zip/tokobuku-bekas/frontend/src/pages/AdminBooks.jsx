import React, { useEffect, useState } from "react";
import { getBooks, createBook, updateBook, deleteBook } from "../api/books";
import Modal from "../components/Modal";
import BookForm from "../components/BookForm";

export default function AdminBooks() {
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  const fetchBooks = async () => {
    setLoading(true);
    try {
      const data = await getBooks();
      setBooks(data);
    } catch {
      setError("Gagal memuat data buku.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBooks();
  }, []);

  const openCreate = () => {
    setEditing(null);
    setModalOpen(true);
  };

  const openEdit = (book) => {
    setEditing(book);
    setModalOpen(true);
  };

  const handleSubmit = async (data) => {
    setSubmitting(true);
    setError("");
    try {
      if (editing) {
        await updateBook(editing.id, data);
      } else {
        await createBook(data);
      }
      setModalOpen(false);
      fetchBooks();
    } catch (err) {
      setError(err?.response?.data?.message || "Gagal menyimpan buku.");
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (book) => {
    if (!confirm(`Hapus buku "${book.title}"?`)) return;
    try {
      await deleteBook(book.id);
      fetchBooks();
    } catch (err) {
      alert(err?.response?.data?.message || "Gagal menghapus buku.");
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <div className="flex items-center justify-between mb-6">
        <h1 className="font-display text-2xl font-bold text-woodDark">Kelola Buku</h1>
        <button onClick={openCreate} className="px-5 py-2.5 rounded-full bg-wood text-cream font-semibold hover:bg-woodDark transition">
          + Tambah Buku
        </button>
      </div>

      {error && <p className="text-rust bg-rust/10 rounded-lg px-4 py-2 mb-4 text-sm">{error}</p>}

      <div className="bg-white border border-parchment rounded-2xl overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-ink/50 border-b border-parchment">
              <th className="px-4 py-3">Judul</th>
              <th className="px-4 py-3">Penulis</th>
              <th className="px-4 py-3">Kategori</th>
              <th className="px-4 py-3">Kondisi</th>
              <th className="px-4 py-3">Harga</th>
              <th className="px-4 py-3">Stok</th>
              <th className="px-4 py-3 text-right">Aksi</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={7} className="text-center py-8 text-ink/40">Memuat...</td></tr>
            ) : books.length === 0 ? (
              <tr><td colSpan={7} className="text-center py-8 text-ink/40">Belum ada buku.</td></tr>
            ) : (
              books.map((book) => (
                <tr key={book.id} className="border-b border-parchment/60 hover:bg-parchment/30">
                  <td className="px-4 py-3 font-medium">{book.title}</td>
                  <td className="px-4 py-3 text-ink/70">{book.author}</td>
                  <td className="px-4 py-3 text-ink/70">{book.category}</td>
                  <td className="px-4 py-3 text-ink/70">{book.condition}</td>
                  <td className="px-4 py-3 text-ink/70">Rp {Number(book.price).toLocaleString("id-ID")}</td>
                  <td className="px-4 py-3 text-ink/70">{book.stock}</td>
                  <td className="px-4 py-3 text-right whitespace-nowrap">
                    <button onClick={() => openEdit(book)} className="text-wood hover:underline mr-3">Edit</button>
                    <button onClick={() => handleDelete(book)} className="text-rust hover:underline">Hapus</button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "Edit Buku" : "Tambah Buku"}>
        <BookForm
          initial={editing}
          onSubmit={handleSubmit}
          onCancel={() => setModalOpen(false)}
          submitting={submitting}
        />
      </Modal>
    </div>
  );
}
