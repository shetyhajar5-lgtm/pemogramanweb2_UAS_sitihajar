import React, { useState } from "react";
import { useNavigate, Navigate } from "react-router-dom";
import { useCart } from "../context/CartContext";
import { createOrder } from "../api/orders";

export default function Checkout() {
  const { items, total, clearCart } = useCart();
  const navigate = useNavigate();
  const [form, setForm] = useState({ customer_name: "", customer_email: "", customer_phone: "", customer_address: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  if (items.length === 0) return <Navigate to="/cart" replace />;

  const handleChange = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const order = await createOrder({
        ...form,
        items: items.map((i) => ({ book_id: i.book_id, quantity: i.quantity })),
      });
      clearCart();
      navigate(`/order-success/${order.id}`);
    } catch (err) {
      setError(err?.response?.data?.message || "Gagal membuat pesanan. Coba lagi.");
    } finally {
      setLoading(false);
    }
  };

  const inputClass = "w-full border border-parchment rounded-lg px-3 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-wood/40";

  return (
    <div className="max-w-3xl mx-auto px-4 py-10">
      <h1 className="font-display text-2xl font-bold text-woodDark mb-6">Checkout</h1>

      <div className="grid md:grid-cols-2 gap-8">
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div>
            <label className="text-sm font-medium text-ink/70">Nama Lengkap *</label>
            <input required name="customer_name" value={form.customer_name} onChange={handleChange} className={inputClass} />
          </div>
          <div>
            <label className="text-sm font-medium text-ink/70">Email *</label>
            <input required type="email" name="customer_email" value={form.customer_email} onChange={handleChange} className={inputClass} />
          </div>
          <div>
            <label className="text-sm font-medium text-ink/70">No. Telepon</label>
            <input name="customer_phone" value={form.customer_phone} onChange={handleChange} className={inputClass} />
          </div>
          <div>
            <label className="text-sm font-medium text-ink/70">Alamat Pengiriman *</label>
            <textarea required name="customer_address" value={form.customer_address} onChange={handleChange} rows={3} className={inputClass} />
          </div>

          {error && <p className="text-rust bg-rust/10 rounded-lg px-4 py-2 text-sm">{error}</p>}

          <button
            type="submit"
            disabled={loading}
            className="mt-2 py-3 rounded-full bg-wood text-cream font-semibold hover:bg-woodDark disabled:opacity-50 transition"
          >
            {loading ? "Memproses..." : "Buat Pesanan"}
          </button>
        </form>

        <div className="bg-white border border-parchment rounded-2xl p-5 h-fit">
          <h2 className="font-display font-bold text-woodDark mb-4">Ringkasan Pesanan</h2>
          <div className="flex flex-col gap-2 mb-4">
            {items.map((i) => (
              <div key={i.book_id} className="flex justify-between text-sm">
                <span className="text-ink/70">{i.title} x{i.quantity}</span>
                <span className="font-medium">Rp {(i.price * i.quantity).toLocaleString("id-ID")}</span>
              </div>
            ))}
          </div>
          <div className="border-t border-parchment pt-3 flex justify-between font-bold text-wood">
            <span>Total</span>
            <span>Rp {total.toLocaleString("id-ID")}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
