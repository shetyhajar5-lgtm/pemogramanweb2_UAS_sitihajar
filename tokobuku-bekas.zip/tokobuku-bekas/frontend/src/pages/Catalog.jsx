import React, { useEffect, useState } from "react";
import { getBooks } from "../api/books";
import BookCard from "../components/BookCard";

const CATEGORIES = ["Semua", "Fiksi", "Non-Fiksi", "Pengembangan Diri", "Sains", "Sejarah", "Umum"];

export default function Catalog() {
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("Semua");
  const [error, setError] = useState("");

  const fetchBooks = async () => {
    setLoading(true);
    setError("");
    try {
      const data = await getBooks({ search, category });
      setBooks(data);
    } catch (err) {
      setError("Gagal memuat data buku. Pastikan server backend sudah berjalan.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const timeout = setTimeout(fetchBooks, 300);
    return () => clearTimeout(timeout);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, category]);

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <section className="bg-wood rounded-3xl px-8 py-12 mb-10 text-cream overflow-hidden relative">
        <div className="relative z-10 max-w-xl">
          <h1 className="font-display text-3xl md:text-4xl font-black mb-3">Buku Bekas, Cerita Baru</h1>
          <p className="text-cream/90">
            Temukan buku bekas berkualitas dengan harga bersahabat. Setiap buku punya cerita —
            sekarang giliranmu melanjutkannya.
          </p>
        </div>
        <div className="absolute -right-6 -bottom-8 text-[10rem] opacity-20 select-none">📚</div>
      </section>

      <div className="flex flex-col md:flex-row gap-3 mb-8">
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Cari judul atau penulis..."
          className="flex-1 border border-parchment rounded-full px-5 py-2.5 bg-white focus:outline-none focus:ring-2 focus:ring-wood/40"
        />
        <div className="flex gap-2 overflow-x-auto pb-1">
          {CATEGORIES.map((c) => (
            <button
              key={c}
              onClick={() => setCategory(c)}
              className={`whitespace-nowrap px-4 py-2 rounded-full text-sm font-medium transition ${
                category === c ? "bg-wood text-cream" : "bg-white border border-parchment text-ink/70 hover:bg-parchment"
              }`}
            >
              {c}
            </button>
          ))}
        </div>
      </div>

      {error && <p className="text-rust bg-rust/10 rounded-xl px-4 py-3 mb-6">{error}</p>}

      {loading ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="aspect-[3/5] bg-parchment/60 rounded-2xl animate-pulse" />
          ))}
        </div>
      ) : books.length === 0 ? (
        <p className="text-center text-ink/50 py-16">Tidak ada buku yang ditemukan.</p>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          {books.map((book) => (
            <BookCard key={book.id} book={book} />
          ))}
        </div>
      )}
    </div>
  );
}
