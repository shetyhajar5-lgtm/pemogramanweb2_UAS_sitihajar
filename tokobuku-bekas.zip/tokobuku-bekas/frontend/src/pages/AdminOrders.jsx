import React, { useEffect, useState } from "react";
import { getOrders, getOrder, updateOrder, deleteOrder } from "../api/orders";
import Modal from "../components/Modal";

const STATUS_LIST = ["pending", "diproses", "dikirim", "selesai", "dibatalkan"];
const STATUS_COLOR = {
  pending: "bg-amber-100 text-amber-700",
  diproses: "bg-blue-100 text-blue-700",
  dikirim: "bg-purple-100 text-purple-700",
  selesai: "bg-leaf/15 text-leaf",
  dibatalkan: "bg-rust/15 text-rust",
};

export default function AdminOrders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("Semua");
  const [detail, setDetail] = useState(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [error, setError] = useState("");

  const fetchOrders = async () => {
    setLoading(true);
    try {
      const data = await getOrders({ status: filter });
      setOrders(data);
    } catch {
      setError("Gagal memuat data transaksi.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filter]);

  const openDetail = async (order) => {
    setDetailOpen(true);
    setDetail(null);
    const full = await getOrder(order.id);
    setDetail(full);
  };

  const handleStatusChange = async (order, status) => {
    try {
      await updateOrder(order.id, { status });
      fetchOrders();
      if (detail?.id === order.id) setDetail((d) => ({ ...d, status }));
    } catch (err) {
      alert(err?.response?.data?.message || "Gagal memperbarui status.");
    }
  };

  const handleDelete = async (order) => {
    if (!confirm(`Hapus transaksi #${order.id}? Stok buku akan dikembalikan.`)) return;
    try {
      await deleteOrder(order.id);
      setDetailOpen(false);
      fetchOrders();
    } catch (err) {
      alert(err?.response?.data?.message || "Gagal menghapus transaksi.");
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <h1 className="font-display text-2xl font-bold text-woodDark">Kelola Transaksi</h1>
        <div className="flex gap-2 overflow-x-auto">
          {["Semua", ...STATUS_LIST].map((s) => (
            <button
              key={s}
              onClick={() => setFilter(s)}
              className={`whitespace-nowrap px-4 py-1.5 rounded-full text-sm font-medium capitalize transition ${
                filter === s ? "bg-wood text-cream" : "bg-white border border-parchment text-ink/70 hover:bg-parchment"
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {error && <p className="text-rust bg-rust/10 rounded-lg px-4 py-2 mb-4 text-sm">{error}</p>}

      <div className="bg-white border border-parchment rounded-2xl overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-ink/50 border-b border-parchment">
              <th className="px-4 py-3">ID</th>
              <th className="px-4 py-3">Pemesan</th>
              <th className="px-4 py-3">Total</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Tanggal</th>
              <th className="px-4 py-3 text-right">Aksi</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={6} className="text-center py-8 text-ink/40">Memuat...</td></tr>
            ) : orders.length === 0 ? (
              <tr><td colSpan={6} className="text-center py-8 text-ink/40">Belum ada transaksi.</td></tr>
            ) : (
              orders.map((order) => (
                <tr key={order.id} className="border-b border-parchment/60 hover:bg-parchment/30">
                  <td className="px-4 py-3 font-medium">#{order.id}</td>
                  <td className="px-4 py-3 text-ink/70">{order.customer_name}</td>
                  <td className="px-4 py-3 text-ink/70">Rp {Number(order.total_amount).toLocaleString("id-ID")}</td>
                  <td className="px-4 py-3">
                    <select
                      value={order.status}
                      onChange={(e) => handleStatusChange(order, e.target.value)}
                      className={`text-xs font-medium capitalize rounded-full px-2 py-1 border-none ${STATUS_COLOR[order.status]}`}
                    >
                      {STATUS_LIST.map((s) => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                  </td>
                  <td className="px-4 py-3 text-ink/60">{new Date(order.created_at).toLocaleDateString("id-ID")}</td>
                  <td className="px-4 py-3 text-right whitespace-nowrap">
                    <button onClick={() => openDetail(order)} className="text-wood hover:underline mr-3">Detail</button>
                    <button onClick={() => handleDelete(order)} className="text-rust hover:underline">Hapus</button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <Modal open={detailOpen} onClose={() => setDetailOpen(false)} title={detail ? `Detail Transaksi #${detail.id}` : "Detail Transaksi"}>
        {!detail ? (
          <p className="text-ink/50">Memuat...</p>
        ) : (
          <div className="flex flex-col gap-4">
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div><p className="text-ink/50">Nama</p><p className="font-medium">{detail.customer_name}</p></div>
              <div><p className="text-ink/50">Email</p><p className="font-medium">{detail.customer_email}</p></div>
              <div><p className="text-ink/50">Telepon</p><p className="font-medium">{detail.customer_phone || "-"}</p></div>
              <div><p className="text-ink/50">Status</p><p className="font-medium capitalize">{detail.status}</p></div>
              <div className="col-span-2"><p className="text-ink/50">Alamat</p><p className="font-medium">{detail.customer_address}</p></div>
            </div>

            <div>
              <p className="text-ink/50 text-sm mb-2">Buku yang dipesan</p>
              <div className="flex flex-col gap-2">
                {detail.items?.map((item) => (
                  <div key={item.id} className="flex justify-between text-sm bg-parchment/40 rounded-lg px-3 py-2">
                    <span>{item.book_title_snapshot} x{item.quantity}</span>
                    <span className="font-medium">Rp {(item.price_at_purchase * item.quantity).toLocaleString("id-ID")}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-between font-bold text-wood border-t border-parchment pt-3">
              <span>Total</span>
              <span>Rp {Number(detail.total_amount).toLocaleString("id-ID")}</span>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
