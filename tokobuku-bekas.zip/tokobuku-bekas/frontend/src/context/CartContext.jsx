import React, { createContext, useContext, useEffect, useState } from "react";

const CartContext = createContext(null);

export function CartProvider({ children }) {
  const [items, setItems] = useState(() => {
    try {
      const saved = localStorage.getItem("cart");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(items));
  }, [items]);

  const addToCart = (book, quantity = 1) => {
    setItems((prev) => {
      const existing = prev.find((i) => i.book_id === book.id);
      if (existing) {
        return prev.map((i) =>
          i.book_id === book.id
            ? { ...i, quantity: Math.min(i.quantity + quantity, book.stock) }
            : i
        );
      }
      return [
        ...prev,
        {
          book_id: book.id,
          title: book.title,
          author: book.author,
          price: book.price,
          image_url: book.image_url,
          stock: book.stock,
          quantity: Math.min(quantity, book.stock),
        },
      ];
    });
  };

  const updateQuantity = (bookId, quantity) => {
    setItems((prev) =>
      prev.map((i) => (i.book_id === bookId ? { ...i, quantity: Math.max(1, Math.min(quantity, i.stock)) } : i))
    );
  };

  const removeFromCart = (bookId) => {
    setItems((prev) => prev.filter((i) => i.book_id !== bookId));
  };

  const clearCart = () => setItems([]);

  const total = items.reduce((sum, i) => sum + Number(i.price) * i.quantity, 0);
  const count = items.reduce((sum, i) => sum + i.quantity, 0);

  return (
    <CartContext.Provider
      value={{ items, addToCart, updateQuantity, removeFromCart, clearCart, total, count }}
    >
      {children}
    </CartContext.Provider>
  );
}

export const useCart = () => useContext(CartContext);
