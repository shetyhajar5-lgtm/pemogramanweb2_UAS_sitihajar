import api from "./axios";

export const getBooks = (params) => api.get("/books", { params }).then((r) => r.data.data);
export const getBook = (id) => api.get(`/books/${id}`).then((r) => r.data.data);
export const createBook = (payload) => api.post("/books", payload).then((r) => r.data.data);
export const updateBook = (id, payload) => api.put(`/books/${id}`, payload).then((r) => r.data.data);
export const deleteBook = (id) => api.delete(`/books/${id}`).then((r) => r.data);
