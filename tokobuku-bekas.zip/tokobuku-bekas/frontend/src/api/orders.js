import api from "./axios";

export const getOrders = (params) => api.get("/orders", { params }).then((r) => r.data.data);
export const getOrder = (id) => api.get(`/orders/${id}`).then((r) => r.data.data);
export const createOrder = (payload) => api.post("/orders", payload).then((r) => r.data.data);
export const updateOrder = (id, payload) => api.put(`/orders/${id}`, payload).then((r) => r.data.data);
export const deleteOrder = (id) => api.delete(`/orders/${id}`).then((r) => r.data);
