import React, { useState } from "react";
import { Link, NavLink } from "react-router-dom";
import { useCart } from "../context/CartContext";

export default function Navbar() {
  const { count } = useCart();
  const [open, setOpen] = useState(false);

  const linkClass = ({ isActive }) =>
    `px-3 py-2 rounded-full text-sm font-medium transition ${
      isActive ? "bg-wood text-cream" : "text-woodDark hover:bg-parchment"
    }`;

  return (
    <header className="sticky top-0 z-40 bg-cream/95 backdrop-blur border-b border-parchment shadow-sm">
      <div className="max-w-6xl mx-auto px-4 flex items-center justify-between h-16">
        <Link to="/" className="flex items-center gap-2 font-display text-xl font-bold text-woodDark">
          <span>📚</span>
          <span>Loka Aksara</span>
        </Link>

        <nav className="hidden md:flex items-center gap-1">
          <NavLink to="/" end className={linkClass}>Katalog</NavLink>
          <NavLink to="/admin/books" className={linkClass}>Kelola Buku</NavLink>
          <NavLink to="/admin/orders" className={linkClass}>Kelola Transaksi</NavLink>
        </nav>

        <div className="flex items-center gap-2">
          <Link
            to="/cart"
            className="relative flex items-center gap-2 bg-wood text-cream px-4 py-2 rounded-full text-sm font-semibold hover:bg-woodDark transition"
          >
            🛒 Keranjang
            {count > 0 && (
              <span className="absolute -top-2 -right-2 bg-rust text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
                {count}
              </span>
            )}
          </Link>
          <button className="md:hidden text-2xl text-woodDark" onClick={() => setOpen(!open)}>
            ☰
          </button>
        </div>
      </div>

      {open && (
        <nav className="md:hidden flex flex-col gap-1 px-4 pb-4">
          <NavLink to="/" end className={linkClass} onClick={() => setOpen(false)}>Katalog</NavLink>
          <NavLink to="/admin/books" className={linkClass} onClick={() => setOpen(false)}>Kelola Buku</NavLink>
          <NavLink to="/admin/orders" className={linkClass} onClick={() => setOpen(false)}>Kelola Transaksi</NavLink>
        </nav>
      )}
    </header>
  );
}
