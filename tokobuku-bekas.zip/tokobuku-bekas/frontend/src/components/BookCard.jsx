import React from "react";
import { Link } from "react-router-dom";

const conditionColor = {
  "Sangat Baik": "bg-leaf/15 text-leaf",
  Baik: "bg-amber-100 text-amber-700",
  Cukup: "bg-rust/15 text-rust",
};

export default function BookCard({ book }) {
  return (
    <Link
      to={`/books/${book.id}`}
      className="group bg-white rounded-2xl overflow-hidden shadow-sm border border-parchment hover:shadow-lg hover:-translate-y-1 transition-all duration-200 flex flex-col"
    >
      <div className="aspect-[3/4] bg-parchment overflow-hidden">
        {book.image_url ? (
          <img
            src={book.image_url}
            alt={book.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            onError={(e) => (e.target.style.display = "none")}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-4xl">📖</div>
        )}
      </div>
      <div className="p-4 flex flex-col gap-1 flex-1">
        <span className={`self-start text-xs px-2 py-0.5 rounded-full font-medium ${conditionColor[book.condition] || "bg-gray-100"}`}>
          {book.condition}
        </span>
        <h3 className="font-display font-bold text-ink leading-snug line-clamp-2">{book.title}</h3>
        <p className="text-sm text-ink/60">{book.author}</p>
        <div className="mt-auto pt-2 flex items-center justify-between">
          <span className="font-bold text-wood">Rp {Number(book.price).toLocaleString("id-ID")}</span>
          <span className="text-xs text-ink/50">Stok: {book.stock}</span>
        </div>
      </div>
    </Link>
  );
}
