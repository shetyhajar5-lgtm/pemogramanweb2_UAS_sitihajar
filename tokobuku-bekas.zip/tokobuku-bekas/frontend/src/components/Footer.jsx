import React from "react";

export default function Footer() {
  return (
    <footer className="bg-woodDark text-parchment mt-16">
      <div className="max-w-6xl mx-auto px-4 py-8 text-sm flex flex-col md:flex-row justify-between gap-2">
        <p className="font-display text-lg">📚 Loka Aksara</p>
        <p className="opacity-80">
          Toko buku bekas — memberi kehidupan kedua untuk setiap buku, sejak {new Date().getFullYear()}.
        </p>
      </div>
    </footer>
  );
}
