import React, { useState } from "react";

const CATEGORIES = ["Fiksi", "Non-Fiksi", "Pengembangan Diri", "Sains", "Sejarah", "Umum"];
const CONDITIONS = ["Sangat Baik", "Baik", "Cukup"];

export default function BookForm({ initial, onSubmit, onCancel, submitting }) {
  const [form, setForm] = useState({
    title: initial?.title || "",
    author: initial?.author || "",
    isbn: initial?.isbn || "",
    category: initial?.category || "Fiksi",
    condition: initial?.condition || "Baik",
    price: initial?.price || "",
    stock: initial?.stock ?? 1,
    description: initial?.description || "",
    image_url: initial?.image_url || "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ ...form, price: Number(form.price), stock: Number(form.stock) });
  };

  const inputClass =
    "w-full border border-parchment rounded-lg px-3 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-wood/40";

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-3">
      <div>
        <label className="text-sm font-medium text-ink/70">Judul Buku *</label>
        <input required name="title" value={form.title} onChange={handleChange} className={inputClass} />
      </div>
      <div>
        <label className="text-sm font-medium text-ink/70">Penulis *</label>
        <input required name="author" value={form.author} onChange={handleChange} className={inputClass} />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-sm font-medium text-ink/70">Kategori</label>
          <select name="category" value={form.category} onChange={handleChange} className={inputClass}>
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="text-sm font-medium text-ink/70">Kondisi</label>
          <select name="condition" value={form.condition} onChange={handleChange} className={inputClass}>
            {CONDITIONS.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-sm font-medium text-ink/70">Harga (Rp) *</label>
          <input required type="number" min="0" name="price" value={form.price} onChange={handleChange} className={inputClass} />
        </div>
        <div>
          <label className="text-sm font-medium text-ink/70">Stok *</label>
          <input required type="number" min="0" name="stock" value={form.stock} onChange={handleChange} className={inputClass} />
        </div>
      </div>
      <div>
        <label className="text-sm font-medium text-ink/70">ISBN</label>
        <input name="isbn" value={form.isbn} onChange={handleChange} className={inputClass} />
      </div>
      <div>
        <label className="text-sm font-medium text-ink/70">URL Gambar Sampul</label>
        <input name="image_url" value={form.image_url} onChange={handleChange} className={inputClass} placeholder="https://..." />
      </div>
      <div>
        <label className="text-sm font-medium text-ink/70">Deskripsi</label>
        <textarea name="description" value={form.description} onChange={handleChange} rows={3} className={inputClass} />
      </div>

      <div className="flex justify-end gap-2 pt-2">
        <button type="button" onClick={onCancel} className="px-4 py-2 rounded-full text-sm font-medium text-ink/70 hover:bg-parchment">
          Batal
        </button>
        <button
          type="submit"
          disabled={submitting}
          className="px-5 py-2 rounded-full text-sm font-semibold bg-wood text-cream hover:bg-woodDark disabled:opacity-50"
        >
          {submitting ? "Menyimpan..." : "Simpan"}
        </button>
      </div>
    </form>
  );
}
