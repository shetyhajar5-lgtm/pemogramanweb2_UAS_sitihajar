/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      fontFamily: {
        serif: ["'Merriweather'", "serif"],
        sans: ["'Inter'", "sans-serif"],
      },
      colors: {
        cream: "#FBF6EF",
        parchment: "#F1E6D3",
        wood: "#7A4E2D",
        woodDark: "#54331C",
        ink: "#2C2420",
        leaf: "#5C7A52",
        rust: "#B5502D",
      },
    },
  },
  plugins: [],
};
